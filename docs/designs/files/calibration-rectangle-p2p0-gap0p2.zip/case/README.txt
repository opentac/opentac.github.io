Printed case for calibration-rectangle-p2p0-gap0p2

Print the bottom and one lid, in TPU (about Shore 85-95A). All three lids fit the same bottom.

  calibration-rectangle-p2p0-gap0p2_case_bottom.stl        bottom tray; the board and the Velostat sit in its pocket
  calibration-rectangle-p2p0-gap0p2_case_top_bumps.stl     lid with shear-sensing bumps, one over each 2x2 group of taxels  <- primary lid
  calibration-rectangle-p2p0-gap0p2_case_top_flat.stl      flat lid, normal force only
  calibration-rectangle-p2p0-gap0p2_case_top_hatched.stl   hatched lid, cut between taxels so a press stays on the taxel under it

Settings (mm):
  pocket depth 0.2, floor 0.6, lid 0.8, skirt 4, fit tolerance 0.2
  rib period 20, gap 10
  bumps: height 2, base 80% of the 2x2 block, top 70% of the base
  hatch: cut through, cut width 0.9, tabs 1.2

The case is cut to this exact board. If the board is regenerated, download it again.
